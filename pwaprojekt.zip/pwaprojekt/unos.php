<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>

<body>


    <?php require_once "header.php" ?>



    <section class="forma">

        <form action="dodajclanak.php" method="POST" enctype="multipart/form-data">
            <div class="form-item"> <label for="title">Naslov vijesti</label>
                <div class="form-field"> <input id="title" type="text" name="title" class="form-field-textual"> </div>
                <span id="titlewarning"></span>
            </div>
            <div class="form-item"> <label for="about">Kratki sadržaj vijesti (do 50 znakova)</label>
                <div class="form-field"> <textarea id="about" name="about" id="" cols="30" rows="10"
                        class="form-field-textual"></textarea> </div>
                        <span id="aboutwarning"></span>
            </div>
            <div class="form-item"> <label for="content">Sadržaj vijesti</label>
                <div class="form-field"> <textarea name="content" id="content" cols="30" rows="10"
                        class="form-field-textual"></textarea> </div>
                        <span id="contentwarning"></span>
            </div>
            <div class="form-item"> <label for="pphoto">Slika:</label>
                <div class="form-field"> <input type="file" accept="image/jpg,image/all" class="input-text"
                        name="pphoto" /> </div>
                        <span id="pphotowarning"></span>
            </div>
            <div class="form-item"> <label for="category">Kategorija vijesti</label>
                
                <div class="form-field"> <select name="category" id="" class="form-field-textual">
                        <option value="sport">Sport</option>
                        <option value="kultura">Kultura</option>
                    </select> </div>
            </div>
            <div class="form-item"> <label>Spremiti u arhivu: <div class="form-field"> <input type="checkbox"
                            name="arhiva"> </div> </label> </div>
            <div class="form-item"> <button type="reset" value="Poništi">Poništi</button> <button type="submit"
                    value="Prihvati" id="submit" name="submit">Prihvati</button> </div>
        </form>
    </section>
    <?php require_once "./footer.php" ?>
    <script>
        	document.getElementById('submit').onclick = function (event) {
			if (document.getElementById('title').value == '') {
				event.preventDefault();
				document.getElementById('title').style.border = '2px solid red';
				document.getElementById('titlewarning').innerHTML = 'Niste unijeli title';
			}
			if (document.getElementById('about').value == '') {
				event.preventDefault();
				document.getElementById('about').style.border = '2px solid red';
				document.getElementById('aboutwarning').innerHTML = 'Niste unijeli about <br>';
			}
			if (document.getElementById('content').value == '') {
				event.preventDefault();
				document.getElementById('content').style.border = '2px solid red';
				document.getElementById('contentwarning').innerHTML = 'Niste unijeli sadržaj';
			}
			if (document.getElementById('pphoto').value == '') {
				event.preventDefault();
				document.getElementById('pphoto').style.border = '2px solid red';
				document.getElementById('pphotowarning').innerHTML = 'Niste odabrali sliku';
			}

		}
    </script>
    


</body>

</html>