



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Akshar:wght@300&family=Kdam+Thmor+Pro&family=Roboto+Flex:opsz,wght@8..144,200;8..144,300;8..144,400;8..144,500;8..144,900&display=swap" rel="stylesheet">

</head>
<?php require_once "./header.php" ?>


<body>
            <section>
                <?php
                require_once('./connect.php');
                $sql = "SELECT * FROM novosti WHERE arhiva=1 AND kategorija = 'sport' LIMIT 3";

                $result = mysqli_query($dbc,$sql);

                echo "<h1>SPORT</h1>";
                while ($row= mysqli_fetch_array($result))

                {
                 
                    echo "<article>";
                    
                    echo
                    
                    "
                    <div class='slikatekst'>
                    <h1>".$row['naslov']."</h1> ";
                    echo "<img src='slike/".$row['slika']."'> </div>";
                    echo "<h2>".$row['sazetak']."</h2>";
                    echo "<h3>".$row['kategorija']."</h3>";
                    echo "<div class='sadrzaj'>". $row['tekst']."<br><br><br><br>".$row['datum'];
                    echo "<form method='post' action ='clanak.php'>
                    <button name='odinaclanak' value='".$row['ID']."' type='submit'>Odi na članak</button>
                    </form>";
                    echo "</article>";
                    
                }
                
                
                ?>

<?php
                require_once('./connect.php');
                $sql = "SELECT * FROM novosti WHERE arhiva=1 AND kategorija = 'kultura' LIMIT 3";

                $result = mysqli_query($dbc,$sql);

                echo "<h1>KULTURA</h1>";
                while ($row= mysqli_fetch_array($result))

                {
                 
                    echo "<article>";
                    
                    echo
                    
                    "
                    <div class='slikatekst'>
                    <h1>".$row['naslov']."</h1> ";
                    echo "<img src='slike/".$row['slika']."'> </div>";
                    echo"<div>";
                    echo "<h2>".$row['sazetak']."</h2>";
                    echo "<h3>".$row['kategorija']."</h3>";
                    echo"</div>";
                    echo "<div class='sadrzaj'>". $row['tekst']."<br><br><br><br>".$row['datum'];
                    echo "<form method='post' action ='clanak.php'>
                    <button name='odinaclanak' value='".$row['ID']."' type='submit'>Odi na članak</button>
                    </form>";
                    echo "</article>";
                    
                }
                
                
                ?>
            </section>
            <?php require_once "./footer.php" ?>
</body>
</html>