


<footer>
	<h2>Adrian Tarnai | atarnai@tvz.hr | 2022.</h2>
</footer>
