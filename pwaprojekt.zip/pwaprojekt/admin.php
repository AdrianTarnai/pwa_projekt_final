<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>

<body>


    <?php require_once "./header.php" ?>

    <?php
        require_once('./connect.php');

        

        

    ?>
    <?php

$sql = "SELECT naslov,sazetak,slika, tekst, kategorija, arhiva, ID FROM novosti";

$result = mysqli_query($dbc,$sql) ;
echo"
<section class='forma'>
<table>

";

while ($row = mysqli_fetch_array($result))


{

        echo"

<tr>
<th>NASLOV</th>
<th>SAZETAK</th>
<th>TEKST</th>
<th>SLIKA</th>
<th>ARHIVA</th>
<th>KATEGORIJA</th>
<th>OBRISATI</th>
<th>POTVRDA</th>
</tr>
  
        <form method='post'enctype='multipart/form-data' action='izvrsiadmin.php'>

            <tr>
            <td><input name='title' type ='text' value='".$row['naslov']."'></input></td>
            <td><input name='about' type ='text' value='".$row['sazetak']."'></input></td>
            <td><input name='content'type ='text' value='".$row['tekst']."'></input></td>
            <td><img src='slike/".$row['slika']."'><input type ='file' name='picture'></input></td>
            

        ";
            if($row['arhiva'] == '0')
            { 
                echo '<td><input type="checkbox" name="archive" id="archive"/> Arhiviraj?</td>'; 
            }
            else {
            echo '<td><input type="checkbox" name="archive" id="archive" checked/> Arhiviraj?</td>';
                }
       echo "
            <td><select name='category' name='kategorija' id='kategorija'>
            <option value='sport'>sport</option>
            <option value='kultura'>kultura</option>
          </select></td>
            <td><input name='obrisi' type='submit' value='OBRISI'></td>
            <td><input name='izmjeni' type='submit' value='NAPRAVI IZMJENE'></td>
            <input type='hidden' value='".$row['ID']."' name='id'></input>
             </tr>
        </form>

        ";
    }

    echo"</table>";
    echo"<a href='unos.php'><img src='slike/plusek.png'></a>";
    echo"</section>";
    ?>


    
    </script>
    <?php require_once "./footer.php" ?>


</body>

</html>