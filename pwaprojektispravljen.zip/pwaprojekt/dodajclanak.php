<?php

require_once('./connect.php');

if (isset($_POST['submit']))
{

$naslov=$_POST['title'];
$about=$_POST['about'];
$picture = $_FILES['pphoto']['name'];
$content=$_POST['content'];
$datum = date('d.m.Y');

if (isset($_POST['arhiva'])) {
	$archive=1;
} else {
	$archive=0;
}
$category= $_POST['category'];

$target_dir = 'slike/'.$picture;

move_uploaded_file($_FILES["pphoto"]["tmp_name"], $target_dir);


$sql = "INSERT INTO novosti (naslov,sazetak, tekst, slika, kategorija, arhiva, datum) VALUES (?, ?, ?, ?, ?, ?, '$datum')";
$stmt = mysqli_stmt_init($dbc);
if (mysqli_stmt_prepare($stmt, $sql)) {
	mysqli_stmt_bind_param($stmt, 'sssssd', $naslov, $about, $content, $picture, $category, $archive);
	mysqli_stmt_execute($stmt);
}

header('Location:index.php');
mysqli_close($dbc);

}
?>




